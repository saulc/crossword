for i in range(1,9):
	l = ''
	for j in range(1,9):
		l += '   ' + str(i) + "," + str(j)
	print(l)